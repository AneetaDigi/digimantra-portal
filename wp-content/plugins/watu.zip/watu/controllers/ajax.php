<?php
// ajax calls
function watu_submit() {	
	require_once(WATU_PATH."/controllers/show_exam.php");
}